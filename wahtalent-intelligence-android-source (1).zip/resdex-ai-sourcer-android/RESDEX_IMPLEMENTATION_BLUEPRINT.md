# Resdex AI Sourcer — 60-feature implementation blueprint

## Product constraints
- Offline-first; no paid AI API, hosted inference subscription, or mandatory account.
- Candidate data stays on-device unless the user explicitly exports or shares it.
- LLM output is decision support, not an automated hiring decision.
- Never infer missing candidate facts. Mark missing, conflicting, or low-confidence fields.
- Use job-related criteria only; do not score protected or sensitive personal characteristics.
- Process large batches sequentially with progress, cancellation, and recovery rather than loading every document into memory.

## Intake and document extraction
1. Camera capture with a review queue.
2. Multi-photo capture sessions; capture repeatedly, then process the entire batch.
3. Multi-image selection from the device.
4. Full-resolution camera capture (upgrade from preview capture).
5. Document edge detection and auto-crop.
6. Perspective correction and rotation.
7. Image enhancement for contrast and readability.
8. Text-based PDF extraction.
9. Scanned PDF page rendering and OCR.
10. DOCX/TXT extraction.
11. Multi-page resume grouping.
12. Multiple-candidate segmentation inside a single PDF/image batch.
13. Paste text and mixed-format intake.
14. OCR confidence and field-level uncertainty indicators.
15. Retry, retake, page reorder, remove-page and batch cancellation controls.

## Candidate data intelligence
16. Name, phone, email and location extraction.
17. Current and previous company extraction.
18. Designation and career timeline extraction.
19. Skills taxonomy and synonym normalisation.
20. Education and certification extraction.
21. Total experience calculation from date ranges.
22. Relevant experience calculation against JD skills.
23. Employment-gap detection with date-evidence display.
24. Duplicate detection by contact details and profile similarity.
25. Conflict detection across multiple versions of a resume.
26. Structured editable candidate profiles.
27. Source traceability: each field links to page/text evidence.
28. Missing-field flags; never fabricate values.
29. Candidate tags and notes.
30. Local talent repository with search and filters.

## JD and matching intelligence
31. JD parsing into mandatory, preferred and optional requirements.
32. Editable weighted scoring rubric.
33. Candidate ranking from strongest to weakest match.
34. Mandatory-skill match matrix.
35. Preferred-skill match matrix.
36. Total versus relevant experience comparison.
37. Equivalent title and adjacent-role matching.
38. Domain/project relevance analysis.
39. Evidence-linked explanation for every score.
40. Red flags limited to verifiable job-related inconsistencies or missing evidence.
41. Per-candidate detailed analysis and screening questions.
42. Side-by-side comparison for 2–5 candidates.
43. Human-review states: review, shortlist, hold, reject.
44. Recruiter override and score recalculation.

## Boolean Lab
45. Generate 5–10 distinct Boolean strategies per JD.
46. Editable Boolean strings with copy controls.
47. Broad, balanced and precision searches.
48. Alternate job-title discovery.
49. Skill synonyms, abbreviations and technology variants.
50. Exclusion terms and NOT strategies.
51. Platform-aware syntax presets (Naukri, LinkedIn, Google and GitHub), with caveats for platform differences.

## Productivity, reporting and privacy
52. Interview question and screening checklist generation.
53. Candidate pipeline stages and status history.
54. Excel/CSV export.
55. PDF shortlist and JD analysis reports.
56. JD analytics and match distribution charts.
57. Skill, experience and location distribution analytics.
58. Local encrypted storage, app lock option and explicit delete controls.
59. Local backup/restore with user-selected destination.
60. Batch progress, cancellation, error recovery, audit trail and offline operation.

## Technology choices to evaluate
- OCR: Google ML Kit Text Recognition (on-device).
- Camera: CameraX or full-resolution ActivityResultContracts.TakePicture with FileProvider.
- PDF: Android PdfRenderer for page rendering; a free local PDF text extraction library may be added after compatibility review.
- DOCX: Apache POI only if APK size and memory are acceptable; otherwise start with PDF/TXT and add DOCX after tests.
- Local LLM: llama.cpp GGUF runtime already in the project. Benchmark the existing Llama 3.2 1B Q4 model first; compare Qwen/Gemma alternatives only after checking current model licence, RAM use, latency and output quality.
- Deterministic logic: date parsing, experience calculation, duplicate matching, skill dictionaries, scoring arithmetic, validation and sorting should not depend solely on the LLM.
- Storage: Room database with encryption evaluated before storing real candidate records; do not store sensitive data in logs.

## Current source snapshot status
- Present in this source snapshot: single-photo camera preview, a multi-photo capture queue, multi-image picker, sequential on-device OCR for queued/selected images, local GGUF inference, JD prompt, Boolean prompt and sequential candidate comparison.
- Not yet implemented or verified: the rest of the 60-feature roadmap, full-resolution CameraX capture, edge detection, PDF/DOCX extraction, candidate database, advanced matching UI, full Boolean Lab, encrypted storage, analytics and exports.
- Build status: source has not been compiled in this environment. Use the included GitHub Actions workflow and inspect the build result before installing. Do not uninstall the currently working APK until the new APK is tested.

## Multi-photo capture behaviour in this snapshot
1. Open Candidates.
2. Tap Capture Photo and accept the preview into the queue.
3. Repeat Capture More as many times as needed for the current session.
4. Alternatively tap Add Photos to select multiple images at once.
5. Tap Extract All to run OCR sequentially on the queued camera photos.
6. OCR text is appended to the candidate text area with separators. The recruiter must verify where one candidate ends and another begins.

Note: this initial camera flow uses Android's preview capture contract, which may return reduced-resolution images. A full-resolution CameraX capture pipeline is a required next engineering task for reliable small/blurry text extraction. Large batches should be split into manageable sessions to avoid memory pressure.
