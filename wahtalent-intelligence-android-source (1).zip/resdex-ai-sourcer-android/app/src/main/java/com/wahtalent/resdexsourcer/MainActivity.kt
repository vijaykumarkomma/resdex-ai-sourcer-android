package com.wahtalent.resdexsourcer

import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

private val Navy = Color(0xFF101C32)
private val Blue = Color(0xFF3976D5)
private val Page = Color(0xFFF4F6FA)
private val Ink = Color(0xFF1A2940)
private val Muted = Color(0xFF718096)

class MainActivity : ComponentActivity() {
    private var inference: (suspend (String) -> String)? = null
    private var releaseLoadedModel: (() -> Unit)? = null
    private var modelFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy, background = Page)) {
                SourcerApp(
                    currentModel = { modelFile?.name ?: "No model selected" },
                    selectModel = { uri -> copyAndLoadModel(uri) },
                    generate = { prompt -> runLocalPrompt(prompt) },
                    extractPhotoText = { bitmap, onDone -> extractPhotoText(bitmap, onDone) },
                    extractImageUri = { uri, onDone -> extractImageUri(uri, onDone) }
                )
            }
        }
    }

    private suspend fun copyAndLoadModel(uri: Uri): String = withContext(Dispatchers.IO) {
        val dir = File(getExternalFilesDir("models") ?: filesDir, "models").apply { mkdirs() }
        val target = File(dir, "resdex-model.gguf")
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to open selected model file" }.use { source ->
                target.outputStream().use { output -> source.copyTo(output) }
            }
        }
        require(target.length() > 100_000_000L) { "Selected file is too small to be the expected GGUF model" }
        try { releaseLoadedModel?.invoke() } catch (_: Exception) { }
        val loaded = Llama.loadModel(
            modelPath = target.absolutePath,
            config = LlamaConfig(contextSize = 2048, threads = 4)
        )
        inference = { prompt ->
            Llama.complete(loaded, prompt = prompt, systemPrompt = "You are Resdex AI Sourcer, an evidence-based recruitment assistant. Evaluate only job-related criteria. Do not infer or use protected characteristics. Do not invent missing facts. Human recruiters make all final decisions.", maxTokens = 700).text
        }
        releaseLoadedModel = { Llama.releaseModel(loaded) }
        modelFile = target
        "Model loaded on this phone: ${target.name} (${target.length() / (1024 * 1024)} MB)"
    }

    private suspend fun runLocalPrompt(prompt: String): String = withContext(Dispatchers.IO) {
        val runner = inference ?: error("Select and load your GGUF model first")
        runner(prompt)
    }

    private fun extractImageUri(uri: Uri, onDone: (String) -> Unit) {
        try {
            val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            if (bitmap == null) onDone("Could not read this image. Try another image or use the camera.")
            else extractPhotoText(bitmap, onDone)
        } catch (e: Exception) {
            onDone("Image could not be opened: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    private fun extractPhotoText(bitmap: Bitmap, onDone: (String) -> Unit) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result -> onDone(result.text) }
            .addOnFailureListener { error -> onDone("OCR failed: ${error.localizedMessage ?: "Unknown error"}") }
            .addOnCompleteListener { recognizer.close() }
    }
}

@Composable
private fun SourcerApp(
    currentModel: () -> String,
    selectModel: suspend (Uri) -> String,
    generate: suspend (String) -> String,
    extractPhotoText: (Bitmap, (String) -> Unit) -> Unit,
    extractImageUri: (Uri, (String) -> Unit) -> Unit
) {
    var tab by remember { mutableStateOf("JD") }
    var jd by remember { mutableStateOf("") }
    var profiles by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var modelStatus by remember { mutableStateOf("No model loaded. Select your GGUF file.") }
    var modelReady by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var capturedPhoto by remember { mutableStateOf<Bitmap?>(null) }
    val capturedPhotos = remember { mutableStateListOf<Bitmap>() }
    var cameraStatus by remember { mutableStateOf("") }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap -> capturedPhoto = bitmap }
    val candidateImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            cameraStatus = "Processing ${uris.size} selected image(s) on this device…"
            busy = true
            val extractedParts = mutableListOf<String>()
            var index = 0
            lateinit var processNext: () -> Unit
            processNext = {
                if (index >= uris.size) {
                    val combined = extractedParts.filter { it.isNotBlank() }.joinToString("\n\n---\n\n")
                    if (combined.isNotBlank()) profiles = if (profiles.isBlank()) combined else profiles + "\n\n---\n\n" + combined
                    cameraStatus = "Processed ${uris.size} image(s). ${extractedParts.count { it.isNotBlank() }} contained readable text."
                    busy = false
                } else {
                    extractImageUri(uris[index]) { extracted ->
                        extractedParts.add(extracted)
                        index++
                        processNext()
                    }
                }
            }
            processNext()
        }
    }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            modelStatus = "Copying model into app storage and loading it…"
            scope.launch {
                try {
                    modelStatus = selectModel(uri)
                    modelReady = true
                } catch (e: Exception) {
                    modelReady = false
                    modelStatus = "Model load failed: ${e.message}"
                } finally { busy = false }
            }
        }
    }

    val profileList = remember(profiles) { profiles.split(Regex("\\n\\s*---+\\s*\\n")).map { it.trim() }.filter { it.isNotBlank() } }

    fun runPrompt(prompt: String, label: String) {
        if (!modelReady) { output = "Please select and load your GGUF model first."; return }
        busy = true
        progress = label
        scope.launch {
            try { output = generate(prompt) }
            catch (e: Exception) { output = "Local AI error: ${e.message}" }
            finally { busy = false; progress = "" }
        }
    }

    Column(Modifier.fillMaxSize().background(Page)) {
        Column(Modifier.fillMaxWidth().background(Navy).padding(20.dp)) {
            Text("RESDEX AI SOURCER", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(7.dp))
            Text("Recruitment intelligence,\non your phone.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
            Spacer(Modifier.height(12.dp))
            Text(modelStatus, color = Color(0xFFD1DCEC), fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { picker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*")) }, enabled = !busy) {
                Text("Select / Load GGUF model")
            }
            Text("Choose Llama-3.2-1B-Instruct-Q4_K_M.gguf from Downloads. First load copies it into app storage.", color = Color(0xFFB9C7DA), fontSize = 10.sp)
            if (modelReady) Text("ON-DEVICE AI READY • NO CLOUD API", color = Color(0xFF75E0B4), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("JD", "Boolean", "Candidates").forEach { item ->
                FilterChip(selected = tab == item, onClick = { tab = item; output = "" }, label = { Text(item, fontSize = 11.sp) })
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Text(when(tab) { "JD" -> "Understand the role"; "Boolean" -> "Build sourcing searches"; else -> "Compare candidate profiles" }, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Paste a job description. Process candidate information only when authorised.", fontSize = 11.sp, color = Muted, modifier = Modifier.padding(top = 5.dp, bottom = 12.dp))
            OutlinedTextField(value = jd, onValueChange = { jd = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp), label = { Text("Job description") }, placeholder = { Text("Role, experience, location, mandatory skills…") })
            if (tab == "Candidates") {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { camera.launch(null) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("📷 Capture Photo") }
                    OutlinedButton(onClick = { candidateImagePicker.launch(arrayOf("image/*")) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Add Photos") }
                }
                Text("Capture as many pages or candidate photos as needed. Photos stay in a review queue until you choose to extract them together.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp))
                if (capturedPhotos.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("${capturedPhotos.size} photo(s) queued", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { capturedPhotos.clear(); cameraStatus = "Photo queue cleared." }, enabled = !busy) { Text("Clear") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { camera.launch(null) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("＋ Capture More") }
                        Button(onClick = {
                            busy = true
                            cameraStatus = "Extracting ${capturedPhotos.size} queued photo(s)…"
                            val batch = capturedPhotos.toList()
                            val extractedParts = mutableListOf<String>()
                            var index = 0
                            lateinit var processNextPhoto: () -> Unit
                            processNextPhoto = {
                                if (index >= batch.size) {
                                    val combined = extractedParts.filter { it.isNotBlank() }.joinToString("\n\n---\n\n")
                                    if (combined.isNotBlank()) profiles = if (profiles.isBlank()) combined else profiles + "\n\n---\n\n" + combined
                                    cameraStatus = "Finished ${batch.size} photo(s). ${extractedParts.count { it.isNotBlank() }} contained readable text."
                                    capturedPhotos.clear()
                                    busy = false
                                } else {
                                    extractPhotoText(batch[index]) { extracted ->
                                        extractedParts.add(extracted)
                                        index++
                                        cameraStatus = "Reading photo $index of ${batch.size}…"
                                        processNextPhoto()
                                    }
                                }
                            }
                            processNextPhoto()
                        }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Extract All") }
                    }
                }
                if (cameraStatus.isNotBlank()) Text(cameraStatus, color = Blue, fontSize = 11.sp)
                OutlinedTextField(value = profiles, onValueChange = { profiles = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 190.dp), label = { Text("Candidate profiles (max 100)") }, placeholder = { Text("Candidate A details…\n---\nCandidate B details…") })
                Text("${profileList.size} profiles detected. Separate profiles with a line containing ---.", color = Muted, fontSize = 10.sp)
                Text("Candidates are evaluated one at a time. Large runs may take time and use substantial phone memory.", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = {
                if (jd.isBlank()) output = "Please paste a job description first."
                else if (tab == "JD") runPrompt("Analyse this job description. Return role summary, experience, location, mandatory skills, preferred skills, responsibilities, alternative titles, sourcing keywords, knockout criteria, screening checklist and unclear requirements. Do not invent facts.\n\nJD:\n$jd", "Analysing job description…")
                else if (tab == "Boolean") runPrompt("Create broad, balanced and precision Boolean strings, alternative-title searches and skill searches for this job description. Explain when to use each.\n\nJD:\n$jd", "Generating Boolean searches…")
                else if (profileList.isEmpty()) output = "Paste at least one candidate profile."
                else if (profileList.size > 100) output = "Maximum 100 profiles per run."
                else {
                    busy = true; output = ""
                    scope.launch {
                        try {
                            profileList.forEachIndexed { index, profile ->
                                progress = "Evaluating candidate ${index + 1} of ${profileList.size}…"
                                val prompt = "Compare this candidate with the job description using job-related evidence only. Do not use protected traits. Do not invent facts. Score mandatory skills 40, relevant experience 25, project/domain evidence 20, preferred skills 10, location/work arrangement 5 if specified. Return score /100, verdict, matched skills, gaps/not evidenced, rationale and 3 screening questions. This is decision support only.\n\nJOB DESCRIPTION:\n$jd\n\nCANDIDATE:\n${profile.take(5000)}"
                                output += "\n\n========== CANDIDATE ${index + 1} / ${profileList.size} ==========\n" + generate(prompt)
                            }
                        } catch (e: Exception) { output += "\n\nStopped: ${e.message}" }
                        finally { busy = false; progress = "" }
                    }
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Processing…" else when(tab) { "JD" -> "Analyse job description"; "Boolean" -> "Generate Boolean searches"; else -> "Evaluate ${profileList.size} candidates" })
            }
            if (busy) { Spacer(Modifier.height(10.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()); Text(progress, fontSize = 11.sp, color = Muted) }
            if (output.isNotBlank()) {
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("RESULT", fontSize = 10.sp, color = Blue, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { clipboard.setText(AnnotatedString(output)) }) { Text("Copy") }
                }
                Surface(Modifier.fillMaxWidth().padding(bottom = 28.dp), color = Color.White) { Text(output, Modifier.padding(14.dp), fontSize = 12.sp, color = Ink, lineHeight = 18.sp) }
            }
        }
        capturedPhoto?.let { photo ->
            AlertDialog(
                onDismissRequest = { capturedPhoto = null },
                title = { Text("Review captured page") },
                text = {
                    Column {
                        Image(bitmap = photo.asImageBitmap(), contentDescription = "Captured resume page", modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp), contentScale = ContentScale.Fit)
                        Text("Check that the text is readable before extracting it.", fontSize = 11.sp, color = Muted)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        capturedPhotos.add(photo)
                        cameraStatus = "Photo added to batch. ${capturedPhotos.size} photo(s) queued."
                        capturedPhoto = null
                    }) { Text("Add to batch") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = { capturedPhoto = null; camera.launch(null) }) { Text("Retake") }
                        TextButton(onClick = { capturedPhoto = null }) { Text("Discard") }
                    }
                }
            )
        }
        Text("LOCAL-FIRST • NO AUTOMATED PROFILE SCRAPING • VERIFY AI OUTPUT", Modifier.fillMaxWidth().background(Color.White).padding(10.dp), color = Muted, fontSize = 8.sp)
    }
}
