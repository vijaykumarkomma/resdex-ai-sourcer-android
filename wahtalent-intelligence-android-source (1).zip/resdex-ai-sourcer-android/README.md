# Resdex AI Sourcer — llama.cpp Android build

This revision replaces Gemini Nano with llama.cpp using the Android AAR `dev.ffmpegkit-maintained:llama-android:0.1.1`. It is designed for arm64 Android devices and runs GGUF inference locally. The library exposes `Llama.loadModel`, `Llama.complete`, and `Llama.releaseModel`. See its README: https://github.com/ffmpegkit-maintained/llama-android

## Build
Use GitHub Actions workflow `.github/workflows/build-apk.yml`. Upload this source project to a GitHub repository and run the workflow. It builds a debug APK and uploads it as an artifact.

## Use on phone
1. Install the APK.
2. Tap Select / Load GGUF model.
3. Choose `Llama-3.2-1B-Instruct-Q4_K_M.gguf` from Downloads.
4. Wait while the app copies it to app-private storage and loads it. This needs additional free storage (about another model-sized copy) and memory.
5. Try a short JD first.

## Notes
- Model file is not bundled in the APK.
- First load copies the selected file into app storage; allow several minutes.
- CPU inference may be slow; close other apps and begin with short prompts. A 1B model is useful for basic extraction and drafting but may be less reliable for nuanced candidate ranking.
- The AAR targets arm64-v8a; this APK is intended for modern arm64 Android phones.
- AI outputs are decision support only. Use job-related evidence and human review. Do not automate collection from Naukri, LinkedIn, GitHub or other sites without permission.

## Candidate capture (new)
The Candidates workspace now includes **Open Camera** and **Choose Image**. Captured or selected images are processed with Google ML Kit Text Recognition on-device; extracted text is appended to the candidate input area so it can be structured and analysed locally. You can capture multiple pages one after another. This first capture pass supports camera photos and image files; native multi-page PDF/DOCX extraction, page-edge correction, crop/rotate controls and multi-profile segmentation are planned as the next document-processing upgrade. OCR quality depends on focus, lighting and legibility.

## Multi-photo intake update
The Candidates screen now supports repeatedly capturing photos into a batch queue, selecting multiple images in one file-picker action, and running on-device OCR sequentially across the queued images. Captured pages are appended with separators for recruiter review. This is an initial batch-intake implementation, not the complete document-processing roadmap.

See `RESDEX_IMPLEMENTATION_BLUEPRINT.md` for the full 60-feature roadmap, technology choices, safety rules, and a clear list of what is and is not implemented in this source snapshot.

Important: the camera currently uses Android's preview capture contract and may return reduced-resolution images. Full-resolution CameraX capture, auto-cropping, PDF/DOCX parsing, candidate segmentation, database, advanced ranking UI, Boolean Lab, reports, and encrypted storage remain future implementation tasks. This source has not yet been compiled or verified; use GitHub Actions and test the APK before replacing your working installation.
