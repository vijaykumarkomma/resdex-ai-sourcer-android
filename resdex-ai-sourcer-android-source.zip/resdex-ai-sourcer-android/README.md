# Resdex AI Sourcer — Android on-device build

This is an Android-native source project for a local-first recruitment assistant.

## Important compatibility note
The AI engine in this starter uses Google's ML Kit GenAI Prompt API with Gemini Nano through Android AICore. This is genuinely on-device inference when supported, but **support is device-dependent**. The app checks availability at runtime and does not send candidate text to a cloud AI API. The Gemini Nano model may need to be downloaded to the phone first. The ML Kit API has per-app inference quotas and a context window under 4,000 tokens.

If your phone reports `UNAVAILABLE`, this build cannot run AI on that device using AICore. Do not assume Android 14/15/16 alone guarantees support. A different local engine such as llama.cpp would then need to be integrated and tested for your exact phone.

## Features in this starter
- JD analysis
- Boolean search generation
- Candidate evaluation by pasting profile text
- Up to 100 profiles per run, processed one at a time
- Copyable output
- No app-side candidate database or cloud AI API
- No Resdex login, scraping, browser automation or profile extraction

Large 100-profile runs can be slow and may hit AICore quotas. Start with 2–5 synthetic/test profiles.

## Build APK from an Android phone using GitHub Actions
You can trigger the build from the GitHub mobile website; no Android Studio is required on your phone.

1. Download and extract this ZIP.
2. Create a GitHub account if needed: https://github.com/
3. Create a **new public repository** named `resdex-ai-sourcer-android`. Do not upload real candidate data, CVs, keys or personal information.
4. In the repository, use **Add file → Upload files** and upload the extracted project contents, preserving folders such as `app/` and `.github/`.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab.
7. Select **Build Resdex AI Sourcer APK** and press **Run workflow** (or let the push-triggered workflow run).
8. Wait for the green check mark. Open the completed workflow run and scroll to **Artifacts**.
9. Download `resdex-ai-sourcer-debug-apk`, extract it, then tap `app-debug.apk` on your phone to install. Android may ask you to allow installation from that browser/files app.

GitHub Actions free usage depends on repository visibility and current account limits. Public repositories have free standard-runner usage under GitHub's current policy; private repositories have included quotas. Check current plan limits.

## Build locally in Android Studio
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## First launch
1. Open the app while connected to Wi-Fi.
2. Wait for the app to check Gemini Nano availability.
3. If it reports `DOWNLOADABLE`, tap **Download / prepare on-device model** and keep the app open.
4. If it reports `AVAILABLE`, try a short sample JD.
5. If it reports `UNAVAILABLE`, this device/account/region currently cannot use this AICore model through the app. The app will not fall back to a cloud model.

## Privacy and responsible use
- The app does not save candidate profile text to a server or database.
- Candidate text is passed to the on-device ML Kit GenAI API. Google documents that AICore runs supported inference on-device, but review the ML Kit GenAI additional terms and your organisation's privacy obligations before processing real candidate data.
- Use only information you are authorised to process for genuine recruitment.
- Prefer anonymised candidate IDs and remove phone numbers, email addresses, addresses, government IDs and other unnecessary personal details.
- AI scores are decision-support only. Human review is required.
- This app is not affiliated with Naukri or any sourcing platform.

## Technical references
- ML Kit Prompt API: https://developers.google.com/ml-kit/genai/prompt/android/get-started
- AICore/Gemini Nano: https://developer.android.com/ai/gemini-nano
